-------------------------------------- EPIC CHARACTER DICTIONARY ---------------------------------------------------

A - What is Epic Character Dictionary (ECD)?
    ECD is a serverless web application designed to help writers, artists, content creators, and all creators manage their created characters for movies, TV, music, books, and other creative medium. It uses the following tech stack: Flask, mySQL, Firebase, JWT Web token, and GPT-3 to generate data for your characters from scratch.

B - What are the endpoints for ECD?
    Get all characters: GET /characters ✅
    Get a single character: GET /characters/{id} ✅
    Create a new character: POST /characters
    Update an existing character: PUT /characters/{id}
    Delete an existing character: DELETE /characters/{id}
    Get characters by franchise: GET /characters?franchise={franchise}
    Get characters by writer: GET /characters?writer={writer}