# from sqlalchemy import create_engine, Column, Integer, String, DateTime
# from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy.orm import sessionmaker
# from sqlalchemy import create_engine
from urllib import request
from flask import Flask, jsonify, Blueprint, request
import json, requests

chars = Blueprint('characters', __name__)

characters_list = []

# db = create_engine('mysql://username:password@localhost/database_name')
# Base = declarative_base()

# class Character(Base):
#     __tablename__ = 'characters'
#     id = Column(Integer, primary_key=True)
#     name = Column(String)
#     age = Column(Integer)
#     gender = Column(String)
#     book_series = Column(String)

# Base.metadata.create_all(db)
# Session = sessionmaker(bind=db)

## All Characters ##----------------------------------------------------------------------------------------------------------------
@chars.route('/characters', methods=['GET'])
def characters():
#   # Get the characters from the API
  return "All characters displays"

##----------------------------------------------------------------------------------------------------------------------------------
## Single Character by {id}, Create a Character ##----------------------------------------------------------------------------------
@chars.route('/characters/<id>', methods=['POST'])
def create_character(id):
    name = request.json['name']
    age = request.json['age']
    gender = request.json['gender']
    book_series = request.json['book-series']
    
    new_character = {
        'id': id,
        'name': name,
        'age': age,
        'gender': gender,
        'book-series': book_series
    }
    
    characters_list.append(new_character)
    return{ 'id': id,
        'name': name,
        'age': age,
        'gender': gender,
        'book-series': book_series,
        'message':'Successfully created new character'}, 201


##----------------------------------------------------------------------------------------------------------------------------------
## Single Character by {id}, Get a Single Character ##------------------------------------------------------------------------------    
@chars.route('/characters/<id>', methods=['GET'])
def character(id):
    return jsonify({"id": 1,
                "name":"Jacen Riders",
                "age":25,
                "gender":"Male",
                "book-series":"Timeless Heroes"})


