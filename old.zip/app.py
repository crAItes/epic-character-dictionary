import json
import requests
from flask import Flask, jsonify, request
from characters.character import chars
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)


engine = create_engine('mysql://username:password@localhost/database_name')
Base = declarative_base()



## Main Menu ------------------------------------------------------------------------------------
@app.route('/')
def hello():
    return 'Hello World!'

if __name__ == '__main__':
    app.run()




app.register_blueprint(chars)

